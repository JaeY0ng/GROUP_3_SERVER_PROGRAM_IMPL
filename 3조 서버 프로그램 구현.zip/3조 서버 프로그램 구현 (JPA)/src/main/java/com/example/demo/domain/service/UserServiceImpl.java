package com.example.demo.domain.service;

import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.entity.User;
import com.example.demo.domain.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl {

    @Autowired
    private UserRepository userRepository;

    // 회원가입 처리 (비밀번호 평문으로 저장)
    public void memberJoin(UserDto userDto) throws Exception {
        // UserDto를 User Entity로 변환
        User user = UserDto.dtoToEntity(userDto);

        // 비밀번호를 그대로 저장 (암호화 없이 평문 저장)
        user.setPassword(userDto.getPassword());

        // 기본 역할 지정 (만약 UserDto에 role 정보가 없다면 기본값 설정)
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("USER");
        }

        // User 저장
        userRepository.save(user);
    }

    // 로그인 처리 (비밀번호 평문 비교)
    public boolean memberLogin(UserDto userDto) throws Exception {
        User user = userRepository.findByUsername(userDto.getUsername());

        if (user == null) {
            throw new IllegalArgumentException("유저가 존재하지 않습니다.");
        }

        // 평문 비밀번호 비교
        if (userDto.getPassword().equals(user.getPassword())) {
            return true; // 로그인 성공
        } else {
            throw new IllegalArgumentException("비밀번호가 일치하지 않습니다.");
        }
    }
}
