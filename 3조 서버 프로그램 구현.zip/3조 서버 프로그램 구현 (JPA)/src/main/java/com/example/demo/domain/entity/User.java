package com.example.demo.domain.entity;


import com.example.demo.domain.dto.UserDto;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.bind.DefaultValue;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "userId")
    private Long userId;

    @Column(length=100)
    private String username;

    @Column(length=255,nullable = false)
    private String password;

    @Column(length=255)
    private String role;

    @Column(name = "birthDate", columnDefinition = "DATE")
    @DateTimeFormat(pattern = "yyyy-MM-dd")  // LocalDate에 대한 형식 지정
    private LocalDate birthDate;

    @Column(nullable = false, updatable = false)
    private boolean lended = false;

    public static UserDto entityToDto(User user){
        return UserDto.builder()
                .userId(user.getUserId())
                .username(user.getUsername())
                .password(user.getPassword())
                .role(user.getRole())
                .birthDate(user.getBirthDate())
                .build();
    }

}
