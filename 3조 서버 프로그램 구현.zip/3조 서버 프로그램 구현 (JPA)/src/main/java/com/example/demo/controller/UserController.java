package com.example.demo.controller;

import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.entity.User;
import com.example.demo.domain.service.UserServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@Slf4j
@RequestMapping()
public class UserController {


    @Autowired
    private UserServiceImpl userServiceImpl;

    @GetMapping("/user/register")
    public void join() {
        log.info("GET /join...");
       ;
//        return "join";  // "join.jsp" 뷰를 반환
    }

    @PostMapping("/user/register")
    public String join_post(UserDto userDto) throws Exception {
        log.info("POST /join...");
        userServiceImpl.memberJoin(userDto);
        // 1. form data 받아서 User entity로 mapping

        // 사용자 처리 후 다른 뷰로 리디렉션
        return "redirect:/login";  // 대여 페이지로...
    }

    // 로그인 페이지로 이동
    @GetMapping("/login")
    public String loginPage() {
        return "login"; // login.jsp로 이동
    }

    // 로그인 처리
    @PostMapping("/login")
    public String login(@ModelAttribute UserDto userDto) {
        // 로그인 처리 후 성공적인 로그인 시 리다이렉트
        return "redirect:/lend/add"; // 로그인 후 홈 페이지로 리다이렉트
    }


}
