package com.example.demo.domain.entity;

import com.example.demo.domain.dto.LendDto;
import com.example.demo.domain.entity.Book;
import com.example.demo.domain.entity.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Entity
@Table(name = "lend")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Lend {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long lendId;

    // USER (1-N) LEND 관계
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "userId", referencedColumnName = "userId", foreignKey = @ForeignKey(name = "FK_LEND_USERID"))
    private User user;

    // BOOK (1-N) LEND 관계
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bookCode", referencedColumnName = "bookCode", foreignKey = @ForeignKey(name = "FK_LEND_BOOK"))
    private Book book;

    @CreationTimestamp
    @Column(name = "lendDate")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate lendDate;

    @Column(name = "returnDate")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate returnDate;

    @PrePersist
    public void setReturnDate() {
        if (returnDate == null) {
            this.returnDate = LocalDate.now().plusDays(7); // 기본 반납일을 7일로 설정
        }
    }

    public static LendDto lendToDto(Lend lend){
        return LendDto.builder()
                .lendId(lend.getLendId())
                .lendDate(lend.getLendDate())
                .returnDate(lend.getReturnDate())
                .bookCode(lend.getBook().getBookCode())
                .username(lend.getUser().getUsername())
                .build();

    }

}
