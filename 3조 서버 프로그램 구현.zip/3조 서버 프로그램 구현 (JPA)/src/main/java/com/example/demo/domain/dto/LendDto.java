package com.example.demo.domain.dto;

import com.example.demo.domain.entity.Book;
import com.example.demo.domain.entity.Lend;
import com.example.demo.domain.entity.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LendDto {
    private Long lendId;
    private LocalDate lendDate;
    private LocalDate returnDate;
    private Long bookCode;
    private String username;

    public static Lend dtoToLend(LendDto lendDto){
        return Lend.builder()
                .lendId(lendDto.getLendId())
                .lendDate(lendDto.getLendDate())
                .returnDate(lendDto.getReturnDate())
                .book(Book.builder().bookCode(lendDto.getBookCode()).build())
                .user(User.builder().username(lendDto.getUsername()).build())
                .build();
    }



}
