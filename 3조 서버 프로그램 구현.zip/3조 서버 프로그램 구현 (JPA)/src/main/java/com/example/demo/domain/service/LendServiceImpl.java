package com.example.demo.domain.service;

import com.example.demo.domain.dto.LendDto;
import com.example.demo.domain.entity.Book;
import com.example.demo.domain.entity.Lend;
import com.example.demo.domain.entity.User;
import com.example.demo.domain.repository.BookRepository;
import com.example.demo.domain.repository.LendRepository;
import com.example.demo.domain.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Service
public class LendServiceImpl {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private LendRepository lendRepository;

    //    public boolean addLend(LendDto lendDto) {
//        Lend lend = LendDto.dtoToLend(lendDto);
//        lendRepository.save(lend);
//        return true;
//
//    }

    public void lendBook(LendDto lendDto) {
        // username을 통해 User 객체 조회
        User user = userRepository.selectByUsername(lendDto.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // bookCode를 통해 Book 객체 조회
        Book book = bookRepository.findById(lendDto.getBookCode())
                .orElseThrow(() -> new RuntimeException("Book not found"));

        // 대여 객체 생성 및 저장
        Lend lend = Lend.builder()
                .user(user)
                .book(book)
                .lendDate(LocalDate.now())
                .returnDate(LocalDate.now().plusDays(7)) // 반납일 설정
                .build();

        lendRepository.save(lend);
    }


    public boolean deletebybookCode(Long bookCode) {
        if (lendRepository.existsByBook_bookCode(bookCode)) {
            lendRepository.deleteByBookCode(bookCode);
            return true;
        } else {
            return false;
        }
    }

    public boolean updateReturn(Long lendId) {
//        Lend lend = lendRepository.findByUser_Username(username); //username으로 대여기록을 조회해야 되기 떄문에 username을 기준으로 lend 객체를 찾는 작업이 필요
        Lend lend = lendRepository.findById(lendId)
                  .orElseThrow(() -> new RuntimeException("Lend record not found"));
        LocalDate newReturnDate = lend.getReturnDate().plusDays(7);
        lendRepository.updateReturnDate(newReturnDate, lend.getLendId());
        return true;
    }

    public List<Object[]> lendList(String username) {
        return lendRepository.findLendListByUserAndBook(username);

    }


}
