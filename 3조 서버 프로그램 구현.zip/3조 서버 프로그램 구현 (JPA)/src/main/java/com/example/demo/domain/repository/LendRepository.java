package com.example.demo.domain.repository;

import com.example.demo.domain.entity.Lend;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface LendRepository extends JpaRepository<Lend, Long> {

    @Query("SELECT l FROM Lend l JOIN FETCH l.user WHERE l.user.username = :username")
    List<Lend> findLendsByUser(@Param("username") String username);

    @Query("SELECT b.bookName, b.publisher, b.isbn, l.returnDate FROM Lend l JOIN l.book b WHERE l.user.username = :username")
    List<Object[]> findLendListByUserAndBook(@Param("username") String username);

    @Transactional
    @Modifying
    @Query("DELETE FROM Lend l WHERE l.book.bookCode = :bookCode")
    void deleteByBookCode(@Param("bookCode") Long bookCode);

    boolean existsByBook_bookCode(Long bookCode);

    @Transactional
    @Modifying
    @Query("UPDATE Lend l SET l.returnDate = :returnDate WHERE l.lendId = :lendId")
    void updateReturnDate(@Param("returnDate") LocalDate returnDate, @Param("lendId") long lendId);

}
