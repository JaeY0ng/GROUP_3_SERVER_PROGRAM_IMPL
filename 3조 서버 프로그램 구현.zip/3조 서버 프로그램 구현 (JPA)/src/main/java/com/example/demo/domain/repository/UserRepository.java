package com.example.demo.domain.repository;

import com.example.demo.domain.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, String> {

    User findByUsername(String username);

    @Query("SELECT u FROM User u WHERE u.role = :role")
    List<User> selectByRole(@Param("role") String role);

    @Query("SELECT u FROM User u WHERE u.role = :role AND u.password = :password")
    Optional<User> selectByRoleAndPassword(@Param("role") String role, @Param("password") String password);

    @Query("SELECT u FROM User u WHERE u.password = :password")
    List<User> selectByPassword(@Param("password") String password);

    @Query("SELECT u FROM User u WHERE u.username LIKE CONCAT('%', :username, '%')")
    List<User> selectAllLikeUsername(@Param("username") String username);

    @Query("SELECT u FROM User u WHERE u.username = :username")
    Optional<User> selectByUsername(@Param("username") String username);

}
