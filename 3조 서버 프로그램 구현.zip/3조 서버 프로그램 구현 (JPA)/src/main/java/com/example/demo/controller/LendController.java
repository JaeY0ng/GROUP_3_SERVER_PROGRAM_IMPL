package com.example.demo.controller;

import com.example.demo.domain.dto.LendDto;
import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.service.LendServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.time.LocalDate;
import java.util.List;

@Controller
@Slf4j
@RequestMapping("/lend")
public class LendController {

    @Autowired
    private LendServiceImpl lendServiceImpl;

    // 도서 대여
//    @GetMapping("/add")
//    public void lendadd_get() {
//        log.info("GET /lend/add");
//    }

//    @PostMapping("/add")
//    public String lendadd_post(String username, Long bookCode) throws UnsupportedEncodingException {
//        log.info("POST /lend/add");
//        lendServiceImpl.lendBook(username, bookCode);
//        String encodedUsername = URLEncoder.encode(username, "UTF-8");
//        return "redirect:/lend/list?username=" + encodedUsername;
//    }

    @GetMapping("/add")
    public void lendadd_get(){

        log.info("GET /add");
    }

    @PostMapping("/add")
    public String lendadd_post(@RequestParam("username") String username, @RequestParam("bookCode") Long bookCode) {
        log.info("POST /lend/add");
        LendDto lendDto = new LendDto(null,LocalDate.now(), LocalDate.now().plusDays(7), bookCode, username);
        lendServiceImpl.lendBook(lendDto);
        return "redirect:/lend/list?username=" + username;
    }

    // 도서 반납
    @GetMapping("/returnBook")
    public void returnbook_get() {
        log.info("GET /lend/returnbook");
    }

    @PostMapping("/returnBook")
    public void returnbook_post(@RequestParam("bookCode") Long bookCode) {
        log.info("POST /lend/returnbook: bookCode={}", bookCode);
        lendServiceImpl.deletebybookCode(bookCode);
    }

    // username으로 대여기록 조회
    @GetMapping("/list")
    public String lendlist_get(@RequestParam(value = "username", required = false) String username, Model model) {
        log.info("GET /lend/list...");
        List<Object[]> lendList = lendServiceImpl.lendList(username);
        model.addAttribute("list", lendList);
        return "lend/list";
    }

    @PostMapping("/list")
    public String lendlist_post(@RequestParam("username") String username) throws UnsupportedEncodingException {
        String encodedUsername = URLEncoder.encode(username, "UTF-8");
        return "redirect:/lend/list?username=" + encodedUsername;
    }

    // 반납날짜 연장
    @GetMapping("/day")
    public void lendDay_get() {
        log.info("GET /lend/day...");
    }

    @PostMapping("/day")
    public void lendDay_post(@RequestParam("lendId") Long lendId) {
        log.info("POST /lend/day...");
        lendServiceImpl.updateReturn(lendId);
    }
}
