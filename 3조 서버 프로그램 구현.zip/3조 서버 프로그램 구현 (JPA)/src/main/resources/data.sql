insert ignore into a values(1,11);
insert ignore into a values(2,22);

insert ignore into book values(null,'book1','p1','a1','111');
insert ignore into book values(null,'book2','p2','a2','112');
insert ignore into book values(null,'book3','p3','a3','113');
insert ignore into book values(null,'book4','p4','a4','114');
insert ignore into book values(null,'book5','p5','a5','115');
insert ignore into book values(null,'book6','p6','a6','116');