package com.example.demo.domain.mapper;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemoMapperTest {

    @Autowired
    private MemoMapper memoMapper;

    @Test
    void insertMemo() {
        memoMapper.Insert(new MemoDto(-1,"aa","bb@naver.com"));
    }

}