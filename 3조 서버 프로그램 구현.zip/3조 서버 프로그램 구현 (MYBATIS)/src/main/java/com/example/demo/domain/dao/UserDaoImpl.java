package com.example.demo.domain.dao;

import com.example.demo.domain.dto.UserDto;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.List;


@Repository
public class UserDaoImpl {

    @Autowired
    private SqlSession sqlSession;
    private static String namespace = "com.example.demo.domain.mapper.UserMapper.";

    // 회원 등록
    public int insert(UserDto userDto) throws SQLException {
        sqlSession.insert(namespace + "Insert", userDto);  // 회원 정보 삽입
        return userDto.getId();  // 데이터베이스에서 자동 생성된 회원 ID 반환
    }

    // 회원 정보 수정
    public int update(UserDto userDto) throws SQLException {
        // MyBatis를 사용하여 회원 정보를 업데이트
        int result = sqlSession.update(namespace + "update", userDto);  // "update" 메서드 호출
        return result;  // 수정된 행 수 반환
    }
    // 회원 목록 조회
    public List<UserDto> getUsers() throws SQLException {
        return sqlSession.selectList(namespace + "getUsers");
    }

}

