package com.example.demo.domain.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {

    @NotNull(message = "ID를 입력하세요")  // ID 필드는 필수로 입력받도록 설정
    @Min(value = 1, message = "최소 숫자는 1 이상이어야 합니다.")  // ID는 1 이상의 값이어야 함
    @Max(value = 65535, message = "최대 숫자는 65535 이하이어야 합니다.")  // ID는 65535 이하의 값이어야 함
    private Integer id;  // 회원 ID

    @NotBlank(message = "이름을 입력하세요")  // 이름은 비어있으면 안됨
    private String name;  // 회원 이름

    @NotBlank(message = "이메일을 입력하세요")  // 이메일을 비어두지 않도록 설정
    @Email(message = "유효한 이메일 형식이 아닙니다.")  // 유효한 이메일 형식으로 입력하도록 설정
    private String email;  // 회원 이메일

    @NotNull(message = "생년월일을 입력하세요")  // 생년월일은 필수 입력
    @Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2}$", message = "생년월일은 yyyy-MM-dd 형식이어야 합니다.")  // 날짜 형식 확인 (yyyy-MM-dd)
    private String birthDate;  // 회원 생년월일 (String으로 처리)
}

