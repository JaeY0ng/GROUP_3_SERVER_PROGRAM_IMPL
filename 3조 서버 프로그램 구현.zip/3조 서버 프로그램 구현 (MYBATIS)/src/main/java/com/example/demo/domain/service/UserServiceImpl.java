package com.example.demo.domain.service;

import com.example.demo.domain.dao.UserDaoImpl;
import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.mapper.UserMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

;

@Service
@Slf4j
public class UserServiceImpl {

    @Autowired
    private UserDaoImpl userDaoImpl;

    @Autowired
    private UserMapper userMapper;

    // 회원 등록
    public boolean registerUser(UserDto userDto) {
        // Dao - 회원 Insert 이후 true/false 반환
        int result = userMapper.insert(userDto);
        return result > 0;
    }

    // 회원 수정
    public boolean updateUser(UserDto userDto) {
        int result = userMapper.update(userDto);
        return result > 0;
    }

    // 회원 삭제
    public boolean removeUser(int id) {
        int result = userMapper.delete(id);
        return result > 0;
    }


    // 특정 회원 정보 가져오기
    public UserDto getUser(int id) {
        return userMapper.selectOne(id);
    }

    public List<UserDto> getUsers() {
        List<UserDto> users = userMapper.selectAll();

        // 각 사용자의 필드 확인
        for (UserDto user : users) {
            log.info("User ID: {}, Name: {}, Email: {}, BirthDate: {}",
                    user.getId(), user.getName(), user.getEmail(), user.getBirthDate());
        }

        return users;
    }


}

