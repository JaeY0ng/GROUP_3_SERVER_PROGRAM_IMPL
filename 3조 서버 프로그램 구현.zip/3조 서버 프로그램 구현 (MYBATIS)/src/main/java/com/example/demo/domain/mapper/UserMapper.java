package com.example.demo.domain.mapper;

import com.example.demo.domain.dto.UserDto;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {

    // 회원 등록
    @SelectKey(statement = "select max(id) from users", keyProperty = "id", before = false, resultType = int.class)
    @Insert(value = "insert into users (name, email, birthDate) values (#{name}, #{email}, #{birthDate})")
    public int insert(UserDto userDto);

    // 회원 정보 수정
    @Update(value = "update users set name=#{name}, email=#{email}, birthDate=#{birthDate} where id=#{id}")
    public int update(UserDto userDto);

    // 회원 삭제
    @Delete(value = "delete from users where id=#{id}")
    public int delete(@Param("id") int id);

    // 특정 회원 정보 조회
    @Select(value = "select * from users where id=#{id}")
    public UserDto selectOne(@Param("id") int id);

    // 모든 회원 정보 조회
    @Select(value = "select * from users")
    public List<UserDto> selectAll();

    // Map을 반환하는 조회 예시
    @Results(id = "UserResultMap", value = {
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "email", column = "email"),
            @Result(property = "birthDate", column = "birthDate")
    })
    @Select(value = "select id, name, email, birthDate from users")
    public List<Map<String, Object>> selectAllByResultMap();

    // XML을 이용한 Mapping (예시)
    public int insertXml(UserDto userDto);
    public int updateXml(UserDto userDto);
    public int deleteXml(@Param("id") int id);
    public UserDto selectOneXml(@Param("id") int id);
    public List<UserDto> selectAllXml1();
    public List<Map<String, Object>> selectAllXml2();
    public List<Map<String, Object>> selectAllXml3();
    public List<Map<String, Object>> selectIfXml(Map<String, Object> param);
    public List<Map<String, Object>> selectWhenXml(Map<String, Object> param);
}
