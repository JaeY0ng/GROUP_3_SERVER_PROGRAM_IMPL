package com.example.demo.user;

import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.service.UserServiceImpl;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/user")
@Slf4j
public class UserController {

    @Autowired
    private UserServiceImpl userServiceImpl;

    @InitBinder
    public void dataBinder(WebDataBinder webDataBinder) {
        log.info("UserController's dataBinder..." + webDataBinder);
        // birthDate를 String 타입으로 처리하도록 수정
        webDataBinder.registerCustomEditor(String.class, "birthDate", new BirthDateEditor());
    }

    @Slf4j
    private static class BirthDateEditor extends PropertyEditorSupport {
        @Override
        public void setAsText(String birthDate) throws IllegalArgumentException {
            // 빈 값일 경우 처리 (현재 날짜로 설정)
            if (birthDate.isEmpty()) {
                setValue(LocalDate.now().toString());  // String 타입으로 처리
            } else {
                // 필요에 따라 문자 처리 (ex: "-"으로 분리된 날짜 문자열 처리 등)
                setValue(birthDate.replaceAll("#", "-"));
            }
        }
    }


    // GET 요청으로 회원 등록 페이지를 보여줍니다.
    @GetMapping("/register")
    public void register_get() {
        log.info("GET /user/register...");
    }

    // POST 요청으로 회원 등록 처리
    @PostMapping("/register")
    public String register_post(@ModelAttribute @Valid UserDto userDto, BindingResult bindingResult, Model model) throws Exception {
        log.info("POST /user/register..." + userDto);

        // 유효성 검사 실패 시 오류 메시지 출력
        if (bindingResult.hasErrors()) {
            for (FieldError error : bindingResult.getFieldErrors()) {
                log.info("Error Field : " + error.getField() + " Error Msg : " + error.getDefaultMessage());
                model.addAttribute(error.getField(), error.getDefaultMessage());
            }
        }



        // 회원 등록 서비스 실행
        boolean isRegistered = userServiceImpl.registerUser(userDto);

        if (isRegistered) {
            log.info("회원 등록 성공");
        } else {
            log.info("회원 등록 실패");
        }
        // 회원 가입 후 리스트 페이지로 리다이렉트
        return "redirect:/user/list";  // 회원 가입 후 리스트 페이지로 리다이렉트
    }

    // 회원 목록 페이지
    @GetMapping("/list")
    public String list(Model model) {
        log.info("GET /user/list...");

        // 모든 회원 정보를 가져옵니다
        List<UserDto> users = userServiceImpl.getUsers();
        // model에 users 리스트를 전달
        model.addAttribute("users", users);

        return "user/list"; // list.jsp 페이지를 반환
    }



    // 회원 정보 수정 페이지
    @GetMapping("/edit/{id}")
    public String editUser(@PathVariable("id") int id, Model model) {
        log.info("GET /user/edit/{}", id);
        // 회원 정보를 가져옵니다
        UserDto user = userServiceImpl.getUser(id);
        model.addAttribute("user", user);
        return "user/edit"; // 수정 폼 페이지를 반환합니다
    }

    // 회원 정보 수정 처리
    @PostMapping("/update")
    public String updateUser(@ModelAttribute @Valid UserDto userDto, BindingResult bindingResult, Model model) {
        log.info("POST /user/update...");

        // 유효성 검사 실패 시 오류 메시지 출력
        if (bindingResult.hasErrors()) {
            for (FieldError error : bindingResult.getFieldErrors()) {
                log.info("Error Field : " + error.getField() + " Error Msg : " + error.getDefaultMessage());
                model.addAttribute(error.getField(), error.getDefaultMessage());
            }
            return "user/edit"; // 수정 폼을 다시 반환합니다
        }

        // 회원 정보 수정 서비스 실행
        boolean isUpdated = userServiceImpl.updateUser(userDto);
        if (isUpdated) {
            log.info("회원 정보 수정 성공");
            return "redirect:/user/list"; // 수정 후 목록 페이지로 리디렉션
        } else {
            log.info("회원 정보 수정 실패");
            return "error"; // 수정 실패 시 오류 페이지로 이동
        }

    }
    // 회원 삭제 처리
    @PostMapping("/delete")
    public String deleteUser(@RequestParam("id") int id) {
        log.info("POST /user/delete... 회원 ID: " + id);

        // 회원 삭제 서비스 실행
        boolean isDeleted = userServiceImpl.removeUser(id);

        if (isDeleted) {
            log.info("회원 삭제 성공");
        } else {
            log.info("회원 삭제 실패");
        }

        // 삭제 후 회원 목록으로 리디렉션
        return "redirect:/user/list";
    }

    // 특정 회원 정보 조회 페이지
    @GetMapping("/view/{id}")
    public String viewUser(@PathVariable("id") int id, Model model) {
        log.info("GET /user/view/{}", id);

        // 회원 정보를 가져옵니다.
        UserDto user = userServiceImpl.getUser(id);

        if (user != null) {
            model.addAttribute("user", user); // 모델에 회원 정보 추가
            return "user/view"; // view.jsp 페이지를 반환
        } else {
            log.info("해당 ID의 회원을 찾을 수 없습니다.");
            return "error"; // 회원이 존재하지 않으면 오류 페이지로 리디렉션
        }
    }
}
